export class CreateCatDto{
    
}